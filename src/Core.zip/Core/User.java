package Core;

import Server.Server;

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.StreamTokenizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class User implements Serializable, Comparable<Couch> {

    static int UNIQUE_ID = 0;
    private int id = ++UNIQUE_ID;
    private String nameUser;
    private String login;
    private String password;
    private List<Couch> arrayCouch;

    public User(){
        arrayCouch = new ArrayList<Couch>();
    }

    public User(String nameUser, String login, String password){
        //this.id = Database.getId();
        this.login = login;
        this.nameUser = nameUser;
        this.password = password;
        this.arrayCouch = new ArrayList<Couch>();
    }

    public static void setUniqueId(int uniqueId) {
        UNIQUE_ID = uniqueId;
    }

    public User(String nameUser, String login,  String password, List<Couch> arrayCouch){
        //this.id = Database.getId();
        this.login = login;
        this.nameUser = nameUser;
        this.password = password;
        this.arrayCouch = arrayCouch;
    }

    public User(int id, String login, String nameUser) {
        this.id = id;
        this.login = login;
        this.nameUser = nameUser;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public String getNameUser() {
        return nameUser;
    }

    public String getPassword() {
        return password;
    }

    public List<Couch> getArrayPosts() {
        return arrayCouch;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public void setNameUser(String nameUser) {
        this.nameUser = nameUser;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setArrayPosts(List<Couch> arrayCouch) {
        this.arrayCouch = arrayCouch;
    }

    public int getLength(){ return this.arrayCouch.size(); }

    public void addElementToIndex(int index, Couch Couch){
        this.arrayCouch.add(index, Couch);
    }

    public void addElement(Couch Couch){
        this.arrayCouch.add(Couch);
    }

    public void deleteElement(int index){
        this.arrayCouch.remove(index);
    }

    public void listSort(){
        try {
            Collections.sort(this.arrayCouch);
        }catch (Error e){
            System.out.println(e);
        }
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", login='" + login + '\'' +
                ", nameUser='" + nameUser + '\'' +
                ", arrayPosts=" + arrayCouch.toString() +
                '}';
    }

    @Override
    public int compareTo(Couch couch){
        return this.nameUser.compareTo(couch.getinitials());
    }

    public ArrayList<Integer> read (Reader in){
        StreamTokenizer in1= new StreamTokenizer(in);
        String nameUser = "";
        ArrayList<Integer> ints = new ArrayList<Integer>();
        try {
            in1.nextToken();
            this.id = (int)in1.nval;
            in1.nextToken();
            for (int i=0; i<3; ++i) {
                nameUser = nameUser + in1.sval + " ";
                in1.nextToken();
            }
            setNameUser(nameUser);
            setLogin(in1.sval);
            in1.nextToken();
            setPassword(in1.sval);
            while (in1.nextToken() != StreamTokenizer.TT_EOF){
                ints.add(new Integer((int)in1.nval));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return ints;
    }
}

