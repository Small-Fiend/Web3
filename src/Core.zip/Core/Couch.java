package Core;



import org.json.JSONObject;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Couch implements Serializable, Comparable<Couch> {
    private String initials;
    private Date birthday;
    private String specialization;
    private String phoneNumber = "";

    public Couch(){}

    public Couch(String initials){
        this.initials = initials;
        this.birthday = null;
        this.specialization = "";
    }

    public Couch(String initials, Date birthday, String specialization, String phoneNumber){
        this.initials = initials;
        this.birthday = birthday;
        this.specialization = specialization;
        this.phoneNumber = phoneNumber;
    }

    public String getinitials() {
        return initials;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getSpecialization() {
        return specialization;
    }


    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public void setinitials(String initials) {
        this.initials = initials;
    }

    public void setPhoneNumber(String phoneNumber) { //проверка на числовой ввод
            try {
               if (phoneNumber.length() == 11){
                Long.parseLong(phoneNumber);
                this.phoneNumber = phoneNumber;
           }
            } catch (NumberFormatException e) {
                System.out.println("!!Error!!\nWrong number entered!!");
            }
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public static Writer writeFile(Couch element, Writer fileSave) {
        try {
            JSONObject writeFile = new JSONObject();
            writeFile.put("initials", element.getinitials());
            writeFile.put("birthday", element.getBirthday());
            writeFile.put("phoneNumber", element.getPhoneNumber());
            writeFile.put("Likes", element.getSpecialization());
            fileSave.write(writeFile.toString());

        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileSave;
    }

    public static void readFile(String filePath, Couch element){
        try {
            File file = new File(filePath);
            FileReader fileReader = new FileReader(file);
            BufferedReader reader = new BufferedReader(fileReader);
            SimpleDateFormat formatt = new SimpleDateFormat("dd.MM.yyyy");
            JSONObject json = new JSONObject(reader.readLine());
            element.setinitials(json.getString("initials"));
            element.setBirthday(formatt.parse(json.getString("birthday")));
            element.setPhoneNumber(json.getString("phoneNumber"));
            element.setSpecialization(json.getString("specialization"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    public static Couch readElement(JSONObject json) throws ParseException {
        SimpleDateFormat formatt = new SimpleDateFormat("dd.MM.yyyy");
        Couch timeElement = new Couch();
        timeElement.setinitials(json.getString("initials"));
        timeElement.setBirthday(formatt.parse(json.getString("birthday")));
        timeElement.setSpecialization(json.getString("specialization"));
        timeElement.setPhoneNumber(json.getString("phoneNumber"));
        return timeElement;
    }

    @Override
    public int compareTo(Couch element) {
        return this.initials.compareTo(element.getinitials());
    }

    @Override
    public String toString(){
        return "initials: " + this.initials +
                " birthday: " + this.birthday +
                " specialization: " + this.specialization +
                " phoneNumber: " + this.phoneNumber;
    }
}
