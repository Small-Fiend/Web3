package Core;

import Exeptions.*;

import javax.swing.*;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Database {
    private static final String CONNECTION_URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String USERNAME = "Liza";
    private static final String PASSWORD = "11";
    private final Connection connection;

    private static final String TableCouch = "Couch";
    private static final String Branch = "Branch"; // ArrayCouch, groupStudent
    private static final String UserTable = "User";
    private static final String UserGroupTable = "UserGroup"; //TEACHERGROUP_TABLE
    private static final String Initials = "FIO"; //STUDENT_ID - параметр сортировки
    private static final String BranchId = "Branch"; //GROUP_ID - идентификатор
    private static final String UserId = "ID"; //Teacher_id
    private int id;
    private String login;
    private String password;
    private String nameUser;
    //private static final String Initials = "initials";
    //private static final String Birthday = "Birthday";
    //private static final String Specialization = "Specialization";
    //private static final String PhoneNumber = "PhoneNumber";


    public Database() throws SQLException {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Locale.setDefault(Locale.ENGLISH);
            connection = DriverManager.getConnection(CONNECTION_URL, USERNAME, PASSWORD);
            connection.setAutoCommit(false);
            System.out.println("Connection as "+USERNAME + " successful");
        } catch (SQLException | ClassNotFoundException e) {
            closeConnection();
            throw new SQLException();
        }
    }

    public void closeConnection() throws SQLException {
        connection.close();
    }

    public void createSchema() throws SQLException {
        CreateTable();
        System.out.println("Tables " + TableCouch +" and "+ Branch +" and "+ " created");
    }

    private boolean executeScript(String script) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement(script);
        boolean resultExecution = preparedStatement.execute();
        preparedStatement.close();
        connection.commit();

        return resultExecution;
    }

    public void CreateTable() throws SQLException {
        dropTable(TableCouch);
        dropTable(Branch);
        String scriptCouch = "crate table" + TableCouch +"(" +
                "Initials varchar(100)," +
                "Birthday DATE NOT NULL," +
                "Specialization varchar(100) not null," +
                "PhoneNumber number(8,0)," +
                "Branch varchar(100) primary key not null )";
        String scriptBranch = "crate table" + Branch +"(" +
                "Branch varchar(100) foreign key ("+Branch+") references "+ TableCouch +"("+Branch+")" +
                BranchId +"number(8,0) foreign key NOT NULL references ID )"; //чтобы связывать с User
        /*String scriptGroups = "create table " + GROUPS_TABLE + "  (" +  //Couch
                GROUP_ID +" NUMBER(8,0) primary key not null, " +
                "PRESIDENT  NUMBER(8,0)" +
                ")";
        String scriptStudents = "create table "+ STUDENTS_TABLE +"(" +  //User
                STUDENT_ID + " number(8,0) primary key not null," +
                "Name varchar(50) not null," +
                GROUP_ID+" number(8,0)," +
                "GraduateSubscript varchar(30)," +
                "averagePoint number (3,2) check (averagePoint>=0 and averagePoint<=5)," +
                "foreign key ("+GROUP_ID+") references "+ GROUPS_TABLE +" ("+GROUP_ID+")" +
                ")";*/
        String scriptUsers = "create table "+UserTable+" (" +
                BranchId +" number(8,0) primary key not null," +
                "Name varchar(50) not null," +
                "Login varchar(30) not null unique," +
                "Password varchar(30) not null" +
                ")";
        String scriptUsersGroups = "create table " + UserGroupTable + "  (" +
                UserId+" NUMBER(8,0) not null, " +
                BranchId +"  NUMBER(8,0) not null," +
                "foreign key ("+BranchId+") references "+Branch+"("+BranchId+")," +
                "foreign key ("+UserId+") references "+ UserTable +"(" +UserId+")" +
                ")" ;
        Statement statement = connection.createStatement();
        statement.addBatch(scriptCouch);
        statement.addBatch(scriptBranch);;

        statement.executeBatch();
        statement.close();
        connection.commit();
    };

    private boolean dropTable(String tableName) throws SQLException {
        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet tablesResultSet = metaData.getTables(null, null, tableName, null);
        if (!tablesResultSet.next()) return true;

        return executeScript(String.format("DROP Table %s cascade constraints", tableName));
    }

    private String getParams(String ... params){
        return String.join(" , ", params);
    }

    private boolean addObjectIntoTable(String tableName, String ... params) throws SQLException {
        String paramsString = String.join(" , ", params);

        return executeScript(String.format("insert into %s values(%s)", tableName, paramsString));
    }

    //public void AddUserArrayCouch(){};
    //public void DeleteUserCouch(){ };
    //public void DeleteUserArrayCouch(){ };

    private int deleteObjectFromTable(String tableName, String idName, String value) throws SQLException, NoElementInBase {
        DatabaseMetaData metaData = connection.getMetaData();
        ResultSet tablesResultSet = metaData.getTables(null, null, tableName, null);
        if (!tablesResultSet.next()) throw new NoElementInBase("No such table found in base");

        PreparedStatement preparedStatement = connection.prepareStatement(String.format("delete from %s where %s = %s", tableName, idName, value));
        int resultExecutionInt = preparedStatement.executeUpdate();
        preparedStatement.close();
        return resultExecutionInt;
    }

    public Couch getCouchById(int id) throws NoElementInBase, SQLException, IOException {
        PreparedStatement preparedStatement = connection.prepareStatement("select * from "+TableCouch+" where "+Initials+"="+ id);
        ResultSet resultCouch = preparedStatement.executeQuery();

        if(!resultCouch.next()) throw new NoElementInBase("There is no student with id in base");

        Couch co = new Couch();
        co.setBirthday( resultCouch.getDate(1));
        co.setinitials( resultCouch.getString(2));
        co.setSpecialization( resultCouch.getString(4));
        co.setPhoneNumber( resultCouch.getString(5));

        preparedStatement.close();
        return co;
    }

    public User getTeacherById(int id) throws NoElementInBase, SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement("select * from "+UserTable+" where "+UserId+"="+ id);
        ResultSet resultTeach = preparedStatement.executeQuery();

        if(!resultTeach.next()) throw new NoElementInBase("There is no teacher with id in base");

        User user = new User();
        user.setId(id);
        user.setNameUser(resultTeach.getString(2));
        user.setLogin(resultTeach.getString(3));
        user.setPassword(resultTeach.getString(4));

        preparedStatement.close();
        return user;
    }

    public ArrayList<User> getUsersByUserId(int id) throws NoElementInBase, SQLException, IOException {
        PreparedStatement preparedStatement = connection.prepareStatement("select "+UserId+", NAME, LOGIN, PASSWORD from "+UserTable+" left join "+UserGroupTable+" using ("+UserId+") where "+BranchId+" in (select "+BranchId+" from "+Branch+" where "+Initials+"="+id+')');
        ResultSet resultUser = preparedStatement.executeQuery();

        ArrayList<User> list = new ArrayList<>();
        User user;
        while(resultUser.next()){
            user = new User(resultUser.getString(2),resultUser.getString(3),resultUser.getString(4));
            user.setId(resultUser.getInt(1));
            list.add(user);
        }
        preparedStatement.close();
        return list;
    }

    public void fillTeachersBaseFromFiles(String...files) throws SQLException,IOException {
        File file;
        FileReader fr;
        User user;
        ArrayList<Integer> ints;

        PreparedStatement preparedStatement = connection.prepareStatement("insert into "+UserTable+" values(?,?,?,?)");
        PreparedStatement preparedStatement1 = connection.prepareStatement("insert into "+UserTable+" values(?,?)");
        for (String iterFile : files){
            file = new File(iterFile);
            fr = new FileReader(file);
            user = new User();
            ints = user.read(fr);
            fr.close();
            preparedStatement.setInt(1,user.getId());
            preparedStatement.setString(2,user.getNameUser());
            preparedStatement.setString(3,user.getLogin());
            preparedStatement.setString(4,user.getPassword());
            preparedStatement.addBatch();
            //addObjectIntoTable(TEACHER_TABLE, Integer.toString(teacher.getId()), "'"+teacher.getName()+"'", "'"+teacher.getLogin()+"'", "'"+teacher.getPassword()+"'");
            for(Integer group : ints){
                preparedStatement1.setInt(1,group);
                preparedStatement1.setInt(2,user.getId());
                preparedStatement1.addBatch();
                //addObjectIntoTable(UserTable, group.toString(), Integer.toString(teacher.getId()));
            }
        }

        preparedStatement.executeBatch();
        preparedStatement.close();
        preparedStatement1.executeBatch();
        preparedStatement1.close();
        connection.commit();
        System.out.println("Teachers base filled");
    }

    public void updateArrCouch(String oldArrCouch, String newArrCouch){
        AddArrayCouch(new ArrayCouch(newArrCouch, getArrayCouch(oldArrCouch)));//создать конструктор в ArrayCouch
        deleteArrayCouch(new ArrayCouch(oldArrCouch));//создать конструктор в ArrayCouch

    }

    public void AddArrayCouch(ArrayCouch arrayCouch){
        try {
            Connection connection = DriverManager.getConnection(CONNECTION_URL, USERNAME, PASSWORD);
            PreparedStatement preparedStatement = connection.prepareStatement("insert .... допишешь его");
            preparedStatement.setString(1, значения);
            //и так сколько надо пихать можно любые типы, просто выбери

            preparedStatement.executeUpdate();

            E nt,


        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteArrayCouch(ArrayCouch arrayCouch){
        try {
            Connection connection = DriverManager.getConnection(CONNECTION_URL, USERNAME, PASSWORD);
            PreparedStatement preparedStatement = null;
            //сначала удали дополнительные значение, то те с которыми связана таблица
            preparedStatement = connection.prepareStatement("сюда напишешь строку с удалением вместое" +
                    "значений вопросительные знаки");
            //пример delete from branch where = ?
            preparedStatement.setString(1, значение); // вот так вставляешь значения
            preparedStatement.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private List<Couch> getArrayCouch(String Couch) {
        List<Couch> couch = null;
        try {
            Connection connection = DriverManager.getConnection(CONNECTION_URL, USERNAME, PASSWORD);
            PreparedStatement preparedStatement = connection.prepareStatement("select * from couch where ");
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                couch.add(new Couch(rs.getString("Initials"), rs.getDate("Birthday"),
                        rs.getString("Specialization"), rs.getString("PhoneNumber ")));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return couch;
    }
}
